# CLAUDE.md — Synthetic Situated Dialogue Pipeline

## Your Role

You are a Claude Code session building infrastructure for **structural transfer** of dialogue from reference games (Oblivion, Fallout NV, Skyrim) to synthetic target settings. You are the orchestrator — you build tools, call subagents, and persist outputs.

## The Goal

Create a pipeline that:
1. Samples walks from existing dialogue graph API (localhost:8000)
2. Extracts structural triplets (emotion arcs, barrier/attractor patterns)
3. Translates to target settings via subagent calls
4. Validates outputs against structural constraints
5. Persists to synthetic corpus splits

The output is **freely distributable training data** that has the communicative structure of the reference games without their copyrighted tokens.

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│  YOU (Claude Code Orchestrator)                             │
│  - Build API endpoints                                      │
│  - Manage workflow                                          │
│  - Call subagents                                           │
│  - Persist synthetics                                       │
└─────────────────────┬───────────────────────────────────────┘
                      │
        ┌─────────────┼─────────────┐
        ▼             ▼             ▼
┌──────────────┐ ┌──────────────┐ ┌──────────────┐
│ TRIPLET      │ │ LORE BIBLE   │ │ TRANSLATION  │
│ EXTRACTOR    │ │ CURATOR      │ │ ENGINE       │
│ (Haiku)      │ │ (Opus)       │ │ (Sonnet)     │
│              │ │              │ │              │
│ Structural   │ │ Proper nouns │ │ Prose        │
│ parsing      │ │ Factions     │ │ generation   │
│ Beat labels  │ │ Tensions     │ │ Register     │
│ Arc shapes   │ │ Validation   │ │ matching     │
└──────────────┘ └──────────────┘ └──────────────┘
```

---

## Existing Infrastructure

The dialogue graph API at `localhost:8000` already provides:

```
GET  /api/games             - List available games
GET  /api/stats/{game}      - Graph statistics
GET  /api/transitions/{game} - Emotion transition matrix
POST /api/sample            - Sample walks from graph
POST /api/subgraph          - Extract neighborhood around node
GET  /api/bridge/matrix     - Cross-game emotion bridge stats
POST /api/bridge/walk       - Cross-game random walk
POST /api/bridge/coverage   - Walk that covers all games
GET  /api/query/topics      - List topics by category
POST /api/query/walk        - Topic chain walk
```

You are EXTENDING this API, not replacing it.

---

## Endpoints You Need to Build

### 1. Structure Extraction

```python
@app.post("/api/extract/triplet")
async def extract_triplet(walk: List[DialogueNode], reference_bible: str):
    """
    Call TRIPLET_EXTRACTOR subagent (Haiku) to parse structural arc.
    
    Input: Raw dialogue walk from /api/bridge/walk
    Output: {
        arc: [{beat, emotion, function, archetype_relation, transition}],
        proper_nouns_used: [str],
        barrier_type: str,  # "confrontation", "negotiation", "revelation"
        attractor_type: str # "reward", "information", "alliance", "survival"
    }
    """
    pass

@app.post("/api/extract/quest_shape")
async def extract_quest_shape(community_id: int, game: str):
    """
    Analyze a graph community to infer quest structure.
    
    Output: {
        shape: str,  # "two_claimants", "escort", "fetch", "investigation"
        factions: [{id, archetype, wants, offers}],
        revelation_sequence: [str],
        outcomes: [str]
    }
    """
    pass
```

### 2. Lore Bible Management

```python
@app.get("/api/bibles")
async def list_bibles():
    """List all registered lore bibles."""
    pass

@app.get("/api/bibles/{bible_id}")
async def get_bible(bible_id: str):
    """Retrieve full bible YAML."""
    pass

@app.post("/api/bibles")
async def create_bible(bible: LoreBible):
    """Register new lore bible."""
    pass

@app.post("/api/bibles/{bible_id}/propose_addition")
async def propose_addition(bible_id: str, addition: BibleAddition):
    """
    Propose adding proper noun / faction / tension to bible.
    Calls LORE_BIBLE_CURATOR subagent (Opus) for validation.
    Returns: {approved: bool, modified_addition: BibleAddition, reasoning: str}
    """
    pass
```

### 3. Translation

```python
@app.post("/api/translate/triplet")
async def translate_triplet(
    triplet: StructuralTriplet,
    source_bible: str,
    target_bible: str,
    model: str = "sonnet"
):
    """
    Call TRANSLATION_ENGINE subagent to remap prose.
    
    Output: {
        translated_texts: [str],
        proper_nouns_introduced: [str],
        register_notes: str,
        confidence: float
    }
    """
    pass

@app.post("/api/translate/quest")
async def translate_quest(
    quest_shape: QuestShape,
    source_bible: str,
    target_bible: str
):
    """
    Translate entire quest structure with sample dialogue.
    """
    pass
```

### 4. Synthetic Persistence

```python
@app.post("/api/synthetic/persist")
async def persist_synthetic(synthetic: SyntheticEntry):
    """Save to synthetic corpus split."""
    pass

@app.get("/api/synthetic/split/{target_bible}")
async def get_synthetic_split(target_bible: str, limit: int = 100):
    """Retrieve synthetics for a target setting."""
    pass

@app.post("/api/synthetic/validate")
async def validate_synthetic(synthetic_id: str):
    """
    Score against structural constraints:
    - Does emotion arc match source?
    - Are proper nouns consistent with bible?
    - Is register appropriate for target setting?
    """
    pass
```

---

## Subagent Invocation Pattern

When you need to call a subagent, use this pattern:

```python
import anthropic

client = anthropic.Anthropic()

def call_subagent(
    system_prompt: str,  # From the subagent's CLAUDE.md
    user_message: str,
    model: str = "claude-sonnet-4-20250514"
) -> str:
    response = client.messages.create(
        model=model,
        max_tokens=4096,
        system=system_prompt,
        messages=[{"role": "user", "content": user_message}]
    )
    return response.content[0].text
```

The subagent CLAUDE.md files are in:
- `./subagents/triplet_extractor/CLAUDE.md`
- `./subagents/lore_curator/CLAUDE.md`  
- `./subagents/translation_engine/CLAUDE.md`

Load these as system prompts when invoking subagents.

---

## Workflow Script

Build `workflow/build_corpus.py`:

```python
async def build_synthetic_corpus(
    source_games: list[str],
    source_bible_id: str,
    target_bible_id: str,
    target_count: int,
    shape_distribution: dict[str, float]  # e.g. {"confrontation": 0.3, "negotiation": 0.4, ...}
):
    """
    Main loop. Run until target_count synthetics validated.
    
    1. Sample walk (prefer underrepresented shapes)
    2. Extract triplet (Haiku)
    3. Translate (Sonnet)
    4. Validate structure
    5. If new proper nouns, propose to curator (Opus)
    6. Persist if valid
    7. Log failures for review
    """
    pass
```

---

## Data Structures

```python
from pydantic import BaseModel
from typing import Optional
from enum import Enum

class EmotionType(str, Enum):
    neutral = "neutral"
    happy = "happy"
    anger = "anger"
    sad = "sad"
    fear = "fear"
    surprise = "surprise"
    disgust = "disgust"
    pained = "pained"

class BeatFunction(str, Enum):
    establish_stakes = "establish_stakes"
    deliver_information = "deliver_information"
    negotiate = "negotiate"
    threaten = "threaten"
    plead = "plead"
    farewell = "farewell"
    react = "react"
    bark = "bark"

class ArchetypeRelation(str, Enum):
    authority_to_subject = "authority_to_subject"
    peer_to_peer = "peer_to_peer"
    supplicant_to_power = "supplicant_to_power"
    merchant_to_customer = "merchant_to_customer"
    ally_to_ally = "ally_to_ally"
    enemy_to_enemy = "enemy_to_enemy"

class StructuralBeat(BaseModel):
    text: str
    emotion: EmotionType
    function: BeatFunction
    archetype_relation: ArchetypeRelation
    transition_from: Optional[EmotionType]

class StructuralTriplet(BaseModel):
    arc: list[StructuralBeat]
    proper_nouns_used: list[str]
    barrier_type: str
    attractor_type: str
    source_walk_id: str
    source_game: str

class ProperNounCluster(BaseModel):
    cluster_name: str
    instances: list[str]
    meaning_note: str
    introduced_by_synthetic: Optional[str]

class FactionTemplate(BaseModel):
    faction_id: str
    archetype: str
    wants: str
    fears: str
    offers: str

class LoreBible(BaseModel):
    bible_id: str
    setting_name: str
    world_logic: dict  # terroir, history_shape, tone
    proper_noun_clusters: list[ProperNounCluster]
    faction_templates: list[FactionTemplate]
    revelation_rules: list[str]

class SyntheticEntry(BaseModel):
    synthetic_id: str
    source_walk_id: str
    source_bible: str
    target_bible: str
    source_triplet: StructuralTriplet
    translated_texts: list[str]
    proper_nouns_introduced: list[str]
    validation_score: float
    created_at: str
```

---

## File Structure to Create

```
dialogue_yoinker/
├── api_server.py              # Extend this
├── subagents/
│   ├── triplet_extractor/
│   │   └── CLAUDE.md
│   ├── lore_curator/
│   │   └── CLAUDE.md
│   └── translation_engine/
│       └── CLAUDE.md
├── bibles/
│   ├── mojave.yaml
│   ├── cyrodiil.yaml
│   └── gallia.yaml
├── workflow/
│   ├── build_corpus.py
│   └── validate_batch.py
├── synthetic/
│   └── gallia/
│       └── *.jsonl
└── CLAUDE.md                  # This file
```

---

## Success Criteria

1. **Structural Fidelity**: Translated dialogue preserves emotion arc shape
2. **Bible Consistency**: Proper nouns match target setting's clusters
3. **Register Appropriateness**: Prose sounds like target setting, not source
4. **Coverage**: Synthetic corpus covers all major quest shapes and emotion transitions
5. **Reproducibility**: Another instance can run the same workflow with same bibles and get structurally similar (not identical) outputs

---

## What You Do NOT Do

- You do not write prose yourself (that's the translation engine)
- You do not validate proper nouns yourself (that's the lore curator)
- You do not parse structure yourself (that's the triplet extractor)
- You BUILD TOOLS and ORCHESTRATE SUBAGENTS

Your job is infrastructure. Let the specialists specialize.
